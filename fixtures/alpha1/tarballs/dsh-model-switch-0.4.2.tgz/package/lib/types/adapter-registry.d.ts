export interface ModelSwitchSearchAdapter {
  readonly provider: string
  supportsModel(model: string): boolean
  search(model: string, request: unknown, signal?: AbortSignal): Promise<unknown>
}
export type ImageOutputFormat = 'png' | 'jpeg' | 'webp'
export interface ModelSwitchImageRequest {
  readonly prompt: string
  readonly path?: string
  readonly source?: string
  readonly outputFormat?: ImageOutputFormat
  readonly aspectRatio?: string
}
export interface ModelSwitchGeneratedImage {
  readonly path: string
  readonly mediaType: string
  readonly width: number
  readonly height: number
  readonly bytes?: number
  readonly attachmentId?: string
  readonly name?: string
  readonly revisedPrompt?: string
}
export interface ModelSwitchImageAdapter {
  readonly provider: string
  supportsModel(model: string): boolean
  generate(model: string, request: ModelSwitchImageRequest, execution: unknown): Promise<ModelSwitchGeneratedImage>
}
export interface ModelSwitchProviderAdapters {
  readonly provider: string
  readonly search?: ModelSwitchSearchAdapter
  readonly image?: ModelSwitchImageAdapter
}
export declare class ModelSwitchAdapterRegistry {
  private readonly entries
  register(adapters: ModelSwitchProviderAdapters): () => void
  get(provider: string): ModelSwitchProviderAdapters | undefined
  list(): readonly ModelSwitchProviderAdapters[]
}
