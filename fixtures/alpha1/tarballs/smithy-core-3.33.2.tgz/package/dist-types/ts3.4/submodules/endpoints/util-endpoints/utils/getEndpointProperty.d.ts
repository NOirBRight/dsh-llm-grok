export { getEndpointProperty } from "./getEndpointProperties";
