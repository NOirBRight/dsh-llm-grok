import { expect, test } from "vitest";

import * as z from "../../index.js";
import { ZodCompileAsyncError, ZodCompileUnsupportedError, compile } from "../compile.js";

// Differential helper: assert compiled schema matches the original on a value.
function expectMatch(schema: z.ZodType, value: unknown) {
  const compiled = compile(schema);
  const original = schema.safeParse(value);
  const fast = compiled.safeParse(value);

  expect(fast.success).toBe(original.success);
  if (original.success && fast.success) {
    expect(fast.data).toEqual(original.data);
  } else if (!original.success && !fast.success) {
    expect(fast.error.issues).toEqual(original.error.issues);
  }
}

// Parse and assert success; return the parsed data for further assertions.
function valid<T extends z.ZodType>(schema: T, value: unknown): z.output<T> {
  const result = schema.safeParse(value);
  if (!result.success) {
    throw new Error(`expected success, got issues: ${JSON.stringify(result.error.issues)}`);
  }
  return result.data;
}

// Parse and assert failure.
function invalid(schema: z.ZodType, value: unknown) {
  const result = schema.safeParse(value);
  expect(result.success).toBe(false);
}

// === Primitives ===

test("string", () => {
  const aot = compile(z.string());
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, "")).toBe("");
  invalid(aot, 123);
  invalid(aot, null);
  invalid(aot, undefined);
});

test("number", () => {
  const aot = compile(z.number());
  expect(valid(aot, 123)).toBe(123);
  expect(valid(aot, 0)).toBe(0);
  expect(valid(aot, -5.5)).toBe(-5.5);
  invalid(aot, Number.NaN); // z.number() rejects NaN
  invalid(aot, Number.POSITIVE_INFINITY); // z.number() rejects Infinity
  invalid(aot, Number.NEGATIVE_INFINITY);
  invalid(aot, "123");
  invalid(aot, null);
});

test("boolean", () => {
  const aot = compile(z.boolean());
  expect(valid(aot, true)).toBe(true);
  expect(valid(aot, false)).toBe(false);
  invalid(aot, 1);
  invalid(aot, "true");
});

test("bigint", () => {
  const aot = compile(z.bigint());
  expect(valid(aot, 123n)).toBe(123n);
  expect(valid(aot, 0n)).toBe(0n);
  invalid(aot, 123);
  invalid(aot, "123");
});

test("symbol", () => {
  const aot = compile(z.symbol());
  const sym = Symbol();
  expect(valid(aot, sym)).toBe(sym);
  const namedSym = Symbol.for("test");
  expect(valid(aot, namedSym)).toBe(namedSym);
  invalid(aot, "symbol");
});

test("undefined", () => {
  const aot = compile(z.undefined());
  expect(valid(aot, undefined)).toBe(undefined);
  invalid(aot, null);
  invalid(aot, 0);
});

test("null", () => {
  const aot = compile(z.null());
  expect(valid(aot, null)).toBe(null);
  invalid(aot, undefined);
  invalid(aot, 0);
});

test("void", () => {
  const aot = compile(z.void());
  expect(valid(aot, undefined)).toBe(undefined);
  invalid(aot, null);
  invalid(aot, 0);
});

test("nan", () => {
  const aot = compile(z.nan());
  expect(Number.isNaN(valid(aot, Number.NaN))).toBe(true);
  expect(Number.isNaN(valid(aot, Number.NaN))).toBe(true);
  invalid(aot, 0);
  invalid(aot, Number.POSITIVE_INFINITY);
  invalid(aot, "NaN");
});

test("date", () => {
  const aot = compile(z.date());
  const d1 = new Date();
  expect(valid(aot, d1)).toBe(d1);
  const d2 = new Date(0);
  expect(valid(aot, d2)).toBe(d2);
  invalid(aot, new Date("invalid")); // Invalid date
  invalid(aot, "2024-01-01");
  invalid(aot, Date.now());
});

// === Special Types ===

test("any", () => {
  const aot = compile(z.any());
  expect(valid(aot, null)).toBe(null);
  expect(valid(aot, undefined)).toBe(undefined);
  expect(valid(aot, 123)).toBe(123);
  expect(valid(aot, { nested: { deep: true } })).toEqual({ nested: { deep: true } });
});

test("unknown", () => {
  const aot = compile(z.unknown());
  expect(valid(aot, null)).toBe(null);
  expect(valid(aot, undefined)).toBe(undefined);
  expect(valid(aot, 123)).toBe(123);
});

test("never", () => {
  const aot = compile(z.never());
  invalid(aot, null);
  invalid(aot, undefined);
  invalid(aot, 123);
});

// === Literal ===

test("literal string", () => {
  const aot = compile(z.literal("hello"));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "Hello");
  invalid(aot, "");
});

test("literal number", () => {
  const aot = compile(z.literal(42));
  expect(valid(aot, 42)).toBe(42);
  invalid(aot, 43);
  invalid(aot, "42");
});

test("literal boolean", () => {
  const aot = compile(z.literal(true));
  expect(valid(aot, true)).toBe(true);
  invalid(aot, false);
});

test("literal null", () => {
  const aot = compile(z.literal(null));
  expect(valid(aot, null)).toBe(null);
  invalid(aot, undefined);
});

test("literal bigint", () => {
  const aot = compile(z.literal(100n));
  expect(valid(aot, 100n)).toBe(100n);
  invalid(aot, 100);
  invalid(aot, 101n);
});

// === Enum ===

test("enum", () => {
  const aot = compile(z.enum(["a", "b", "c"]));
  expect(valid(aot, "a")).toBe("a");
  expect(valid(aot, "b")).toBe("b");
  expect(valid(aot, "c")).toBe("c");
  invalid(aot, "d");
  invalid(aot, "A");
  invalid(aot, 1);
});

// === Wrapper Types ===

test("readonly", () => {
  const aot = compile(z.readonly(z.string()));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, 123);
});

test("default", () => {
  const aot = compile(z.string().default("hello"));
  expect(valid(aot, "world")).toBe("world");
  expect(valid(aot, undefined)).toBe("hello"); // default applies
  invalid(aot, 123);
});

test("prefault", () => {
  const aot = compile(z.string().trim().prefault("  hello  "));
  expect(valid(aot, "world")).toBe("world");
  expect(valid(aot, undefined)).toBe("hello");
  invalid(aot, 123);
});

test("nonoptional", () => {
  const aot = compile(z.string().optional().nonoptional());
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, undefined); // nonoptional rejects undefined
  invalid(aot, 123);
});

test("nonoptional judges the inner's output, not its input", () => {
  // An inner catch turns a *defined* input into undefined, which must still be rejected; an inner default turns an absent input into a value, which must be accepted. Testing the input alone got both backwards.
  const caught = z
    .string()
    .min(2)
    .max(8)
    .prefault("abc")
    .catch(undefined as any)
    .optional()
    .nonoptional();
  for (const input of ["abc", "abcdefghij", "a", undefined]) expectMatch(caught, input);

  expectMatch(
    z
      .string()
      .transform(() => undefined)
      .nonoptional(),
    "s"
  );
  for (const input of [undefined, "y", 1]) expectMatch(z.string().default("x").nonoptional(), input);
});

test("a nonoptional object key whose inner supplies a value still needs the key", () => {
  // The runtime separates an absent key from an explicit undefined here: absent fails, explicit undefined takes the default. The fast path has to as well.
  const prop = z
    .literal("lit")
    .default("other" as any)
    .optional()
    .nonoptional();
  const schema = z.object({ k1: prop });
  expectMatch(schema, {});
  expectMatch(schema, { k1: undefined });
  expectMatch(schema, { k1: "lit" });
  expectMatch(prop, undefined);
});

test("success", () => {
  const aot = compile(z.success(z.string()));
  expect(valid(aot, "hello")).toBe(true);
  invalid(aot, 123);
  expectMatch(z.success(z.string()), "hello");
  expectMatch(z.success(z.string()), 123);
  expectMatch(z.object({ ok: z.success(z.number()) }), { ok: 5 });
});

// === Optional & Nullable ===

test("optional", () => {
  const aot = compile(z.optional(z.string()));
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, undefined)).toBe(undefined);
  invalid(aot, null);
  invalid(aot, 123);
});

test("nullable", () => {
  const aot = compile(z.nullable(z.string()));
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, null)).toBe(null);
  invalid(aot, undefined);
  invalid(aot, 123);
});

// === Array ===

test("array of strings", () => {
  const aot = compile(z.array(z.string()));
  expect(valid(aot, [])).toEqual([]);
  expect(valid(aot, ["a", "b"])).toEqual(["a", "b"]);
  invalid(aot, [1, 2]);
  invalid(aot, ["a", 1]);
  invalid(aot, "not array");
});

test("array of objects", () => {
  const aot = compile(z.array(z.object({ id: z.number() })));
  expect(valid(aot, [{ id: 1 }, { id: 2 }])).toEqual([{ id: 1 }, { id: 2 }]);
  invalid(aot, [{ id: "1" }]);
  invalid(aot, [{}]);
});

// === Object ===

test("simple object", () => {
  const aot = compile(z.object({ name: z.string(), age: z.number() }));
  expect(valid(aot, { name: "Alice", age: 30 })).toEqual({ name: "Alice", age: 30 });
  expect(valid(aot, { name: "Bob", age: 25, extra: true })).toEqual({ name: "Bob", age: 25 }); // strip mode
  invalid(aot, { name: "Charlie" });
  invalid(aot, { name: 123, age: 30 });
  invalid(aot, null);
  invalid(aot, []);
});

test("nested object", () => {
  const aot = compile(
    z.object({
      user: z.object({
        name: z.string(),
        address: z.object({
          city: z.string(),
        }),
      }),
    })
  );
  expect(valid(aot, { user: { name: "Alice", address: { city: "NYC" } } })).toEqual({
    user: { name: "Alice", address: { city: "NYC" } },
  });
  invalid(aot, { user: { name: "Alice", address: {} } });
});

test("object with optional property", () => {
  const aot = compile(z.object({ name: z.string(), age: z.optional(z.number()) }));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  expect(valid(aot, { name: "Alice", age: 30 })).toEqual({ name: "Alice", age: 30 });
  expect(valid(aot, { name: "Alice", age: undefined })).toEqual({ name: "Alice", age: undefined });
  invalid(aot, { name: "Alice", age: "30" });
});

test("object required undefined-accepting properties distinguish absence", () => {
  const cases = [
    z.object({ value: z.undefined() }),
    z.object({ value: z.union([z.string(), z.undefined()]) }),
    z.object({ value: z.any() }),
    z.object({ value: z.unknown() }),
  ];

  for (const schema of cases) {
    const aot = compile(schema);
    invalid(aot, {});
    expect(valid(aot, { value: undefined })).toEqual({ value: undefined });
  }
});

test("strictObject", () => {
  const aot = compile(z.strictObject({ name: z.string() }));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  invalid(aot, { name: "Alice", extra: true });
  invalid(aot, {});
});

test("strictObject with optional", () => {
  const aot = compile(z.strictObject({ name: z.string(), age: z.optional(z.number()) }));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  expect(valid(aot, { name: "Alice", age: 30 })).toEqual({ name: "Alice", age: 30 });
  invalid(aot, { name: "Alice", extra: true });
});

test("looseObject", () => {
  const aot = compile(z.looseObject({ name: z.string() }));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  expect(valid(aot, { name: "Alice", extra: true })).toEqual({ name: "Alice", extra: true });
  invalid(aot, {});
});

test("object with catchall", () => {
  const aot = compile(z.object({ name: z.string() }).catchall(z.number()));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  expect(valid(aot, { name: "Alice", age: 30 })).toEqual({ name: "Alice", age: 30 });
  invalid(aot, { name: "Alice", age: "30" });
});

// === Matches Zod behavior ===

test("matches Zod: primitives", () => {
  expectMatch(z.string(), "hello");
  expectMatch(z.string(), 123);
  expectMatch(z.number(), 123);
  expectMatch(z.number(), Number.NaN);
  expectMatch(z.boolean(), true);
  expectMatch(z.boolean(), 1);
});

test("matches Zod: void/nan/date", () => {
  expectMatch(z.void(), undefined);
  expectMatch(z.void(), null);
  expectMatch(z.nan(), Number.NaN);
  expectMatch(z.nan(), 0);
  expectMatch(z.date(), new Date());
  expectMatch(z.date(), new Date("invalid"));
  expectMatch(z.date(), "2024-01-01");
});

test("matches Zod: complex schema", () => {
  const schema = z.strictObject({
    id: z.number(),
    name: z.string(),
    tags: z.array(z.string()),
    nested: z.object({
      active: z.boolean(),
    }),
  });

  expectMatch(schema, { id: 1, name: "test", tags: ["a"], nested: { active: true } });
  expectMatch(schema, { id: 1, name: "test", tags: ["a"], nested: { active: true }, extra: "x" });
  expectMatch(schema, { id: "1", name: "test", tags: ["a"], nested: { active: true } });
});

// === Checks ===

test("number min/max", () => {
  const aot = compile(z.number().min(0).max(100));
  expect(valid(aot, 50)).toBe(50);
  expect(valid(aot, 0)).toBe(0);
  expect(valid(aot, 100)).toBe(100);
  invalid(aot, -1);
  invalid(aot, 101);
});

test("number exclusive min/max", () => {
  const aot = compile(z.number().gt(0).lt(100));
  expect(valid(aot, 50)).toBe(50);
  expect(valid(aot, 1)).toBe(1);
  expect(valid(aot, 99)).toBe(99);
  invalid(aot, 0);
  invalid(aot, 100);
});

test("number int", () => {
  const aot = compile(z.number().int());
  expect(valid(aot, 5)).toBe(5);
  expect(valid(aot, -10)).toBe(-10);
  invalid(aot, 5.5);
});

test("number multipleOf", () => {
  const aot = compile(z.number().multipleOf(5));
  expect(valid(aot, 0)).toBe(0);
  expect(valid(aot, 5)).toBe(5);
  expect(valid(aot, 10)).toBe(10);
  invalid(aot, 7);
});

test("string length checks", () => {
  const aot = compile(z.string().min(3).max(10));
  expect(valid(aot, "abc")).toBe("abc");
  expect(valid(aot, "0123456789")).toBe("0123456789");
  invalid(aot, "ab");
  invalid(aot, "01234567890");
});

test("string exact length", () => {
  const aot = compile(z.string().length(5));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "hi");
  invalid(aot, "toolong");
});

test("string regex", () => {
  const aot = compile(z.string().regex(/^[a-z]+$/));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "Hello");
  invalid(aot, "hello123");
});

test("string startsWith/endsWith/includes", () => {
  const aot = compile(z.string().startsWith("hello").endsWith("world").includes("beautiful"));
  expect(valid(aot, "hello beautiful world")).toBe("hello beautiful world");
  invalid(aot, "hello world");
  invalid(aot, "beautiful world");
});

test("string lowercase/uppercase", () => {
  const lower = compile(z.string().lowercase());
  expect(valid(lower, "hello")).toBe("hello");
  invalid(lower, "Hello");

  const upper = compile(z.string().uppercase());
  expect(valid(upper, "HELLO")).toBe("HELLO");
  invalid(upper, "Hello");
});

test("array length checks", () => {
  const aot = compile(z.array(z.number()).min(1).max(3));
  expect(valid(aot, [1])).toEqual([1]);
  expect(valid(aot, [1, 2, 3])).toEqual([1, 2, 3]);
  invalid(aot, []);
  invalid(aot, [1, 2, 3, 4]);
});

test("bigint min/max", () => {
  const aot = compile(z.bigint().min(0n).max(100n));
  expect(valid(aot, 50n)).toBe(50n);
  expect(valid(aot, 0n)).toBe(0n);
  invalid(aot, -1n);
  invalid(aot, 101n);
});

test("matches Zod: checks", () => {
  const schema = z
    .string()
    .min(3)
    .max(10)
    .regex(/^[a-z]+$/);
  expectMatch(schema, "hello");
  expectMatch(schema, "ab");
  expectMatch(schema, "Hello");
  expectMatch(schema, "toolongstring");
});

test("custom refine", () => {
  const aot = compile(z.string().refine((x) => x.length > 3));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "abc");
  invalid(aot, "ab");
});

test("custom refine with object", () => {
  const aot = compile(
    z
      .object({
        password: z.string(),
        confirm: z.string(),
      })
      .refine((data) => data.password === data.confirm)
  );
  expect(valid(aot, { password: "secret", confirm: "secret" })).toEqual({ password: "secret", confirm: "secret" });
  invalid(aot, { password: "secret", confirm: "wrong" });
});

// === String Formats ===

test("email", () => {
  const aot = compile(z.email());
  expect(valid(aot, "test@example.com")).toBe("test@example.com");
  expect(valid(aot, "user.name+tag@example.co.uk")).toBe("user.name+tag@example.co.uk");
  invalid(aot, "invalid");
  invalid(aot, "@example.com");
  invalid(aot, 123);
});

test("uuid", () => {
  const aot = compile(z.uuid());
  expect(valid(aot, "550e8400-e29b-41d4-a716-446655440000")).toBe("550e8400-e29b-41d4-a716-446655440000");
  expect(valid(aot, "00000000-0000-0000-0000-000000000000")).toBe("00000000-0000-0000-0000-000000000000");
  invalid(aot, "not-a-uuid");
  invalid(aot, "550e8400-e29b-41d4-a716");
});

test("url", () => {
  const aot = compile(z.url());
  expect(valid(aot, "https://example.com")).toBe("https://example.com");
  expect(valid(aot, "  https://example.com  ")).toBe("https://example.com");
  expect(valid(aot, "http://localhost:3000/path")).toBe("http://localhost:3000/path");
  invalid(aot, "not a url");
  invalid(aot, "example.com");
});

test("ipv4", () => {
  const aot = compile(z.ipv4());
  expect(valid(aot, "192.168.1.1")).toBe("192.168.1.1");
  expect(valid(aot, "0.0.0.0")).toBe("0.0.0.0");
  expect(valid(aot, "255.255.255.255")).toBe("255.255.255.255");
  invalid(aot, "192.168.1");
  invalid(aot, "256.0.0.0");
});

test("matches Zod: string formats", () => {
  expectMatch(z.email(), "test@example.com");
  expectMatch(z.email(), "invalid");
  expectMatch(z.uuid(), "550e8400-e29b-41d4-a716-446655440000");
  expectMatch(z.uuid(), "not-a-uuid");
  // z.url() intentionally throws at compile time (see "url is unsupported").
});

// === Tuple ===

test("tuple basic", () => {
  const aot = compile(z.tuple([z.string(), z.number()]));
  expect(valid(aot, ["hello", 42])).toEqual(["hello", 42]);
  invalid(aot, ["hello", "world"]);
  invalid(aot, ["hello"]);
  invalid(aot, ["hello", 42, "extra"]);
  invalid(aot, {});
});

test("tuple with rest", () => {
  const aot = compile(z.tuple([z.string(), z.number()]).rest(z.boolean()));
  expect(valid(aot, ["hello", 42])).toEqual(["hello", 42]);
  expect(valid(aot, ["hello", 42, true])).toEqual(["hello", 42, true]);
  expect(valid(aot, ["hello", 42, true, false])).toEqual(["hello", 42, true, false]);
  invalid(aot, ["hello", 42, "extra"]);
  invalid(aot, ["hello"]);
});

test("tuple empty", () => {
  const aot = compile(z.tuple([]));
  expect(valid(aot, [])).toEqual([]);
  invalid(aot, ["extra"]);
});

test("matches Zod: tuple", () => {
  const schema = z.tuple([z.string(), z.number()]).rest(z.boolean());
  expectMatch(schema, ["hello", 42]);
  expectMatch(schema, ["hello", 42, true, false]);
  expectMatch(schema, ["hello", 42, "not boolean"]);
  expectMatch(schema, ["hello"]);
});

// === Union ===

test("union of primitives", () => {
  const aot = compile(z.union([z.string(), z.number()]));
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, 42)).toBe(42);
  invalid(aot, true);
  invalid(aot, null);
});

test("union of literals (Set optimization)", () => {
  const aot = compile(z.union([z.literal("a"), z.literal("b"), z.literal("c")]));
  expect(valid(aot, "a")).toBe("a");
  expect(valid(aot, "b")).toBe("b");
  expect(valid(aot, "c")).toBe("c");
  invalid(aot, "d");
});

test("union single option", () => {
  const aot = compile(z.union([z.string()]));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, 42);
});

test("union with objects", () => {
  const aot = compile(
    z.union([
      z.object({ type: z.literal("a"), value: z.string() }),
      z.object({ type: z.literal("b"), value: z.number() }),
    ])
  );
  expect(valid(aot, { type: "a", value: "hello" })).toEqual({ type: "a", value: "hello" });
  expect(valid(aot, { type: "b", value: 42 })).toEqual({ type: "b", value: 42 });
  invalid(aot, { type: "a", value: 42 });
  invalid(aot, { type: "c", value: "hello" });
});

test("matches Zod: union", () => {
  const schema = z.union([z.string(), z.number(), z.null()]);
  expectMatch(schema, "hello");
  expectMatch(schema, 42);
  expectMatch(schema, null);
  expectMatch(schema, true);
  expectMatch(schema, undefined);
});

// === Intersection ===

test("intersection of objects", () => {
  const aot = compile(z.intersection(z.object({ name: z.string() }), z.object({ age: z.number() })));
  expect(valid(aot, { name: "Alice", age: 30 })).toEqual({ name: "Alice", age: 30 });
  invalid(aot, { name: "Alice" });
  invalid(aot, { age: 30 });
});

test("intersection deep merge", () => {
  const aot = compile(
    z.intersection(z.object({ nested: z.object({ a: z.string() }) }), z.object({ nested: z.object({ b: z.number() }) }))
  );
  expect(valid(aot, { nested: { a: "x", b: 1 } })).toEqual({ nested: { a: "x", b: 1 } });
});

// === Record ===

test("record basic", () => {
  const aot = compile(z.record(z.string(), z.number()));
  expect(valid(aot, {})).toEqual({});
  expect(valid(aot, { a: 1, b: 2 })).toEqual({ a: 1, b: 2 });
  invalid(aot, { a: "hello" });
  invalid(aot, null);
  invalid(aot, []);
});

test("record with enum keys", () => {
  // Records with enum/literal keys have exhaustive semantics: every enum value must be present in the input. Compile currently forces fallback for this case (see compile.ts generateRecordCheck), so behavior matches the runtime by delegation.
  const aot = compile(z.record(z.enum(["a", "b"]), z.number()));
  expect(valid(aot, { a: 1, b: 2 })).toEqual({ a: 1, b: 2 });
  invalid(aot, { a: 1 }); // missing required key b
  invalid(aot, { c: 3 }); // unknown key
});

test("matches Zod: record", () => {
  const schema = z.record(z.string(), z.number());
  expectMatch(schema, {});
  expectMatch(schema, { a: 1, b: 2 });
  expectMatch(schema, { a: "hello" });
});

// === Map ===

test("map basic", () => {
  const aot = compile(z.map(z.string(), z.number()));
  expect(valid(aot, new Map())).toEqual(new Map());
  expect(
    valid(
      aot,
      new Map([
        ["a", 1],
        ["b", 2],
      ])
    )
  ).toEqual(
    new Map([
      ["a", 1],
      ["b", 2],
    ])
  );
  invalid(aot, new Map([["a", "hello"]]));
  invalid(aot, new Map([[1, 1]]));
  invalid(aot, {});
});

test("matches Zod: map", () => {
  const schema = z.map(z.string(), z.number());
  expectMatch(schema, new Map());
  expectMatch(schema, new Map([["a", 1]]));
  expectMatch(schema, new Map([["a", "hello"]]));
  expectMatch(schema, {});
});

// === Set ===

test("set basic", () => {
  const aot = compile(z.set(z.number()));
  expect(valid(aot, new Set())).toEqual(new Set());
  expect(valid(aot, new Set([1, 2, 3]))).toEqual(new Set([1, 2, 3]));
  invalid(aot, new Set(["hello"]));
  invalid(aot, []);
});

test("set size checks", () => {
  const aot = compile(z.set(z.number()).min(1).max(3));
  expect(valid(aot, new Set([1]))).toEqual(new Set([1]));
  expect(valid(aot, new Set([1, 2, 3]))).toEqual(new Set([1, 2, 3]));
  invalid(aot, new Set());
  invalid(aot, new Set([1, 2, 3, 4]));
});

test("matches Zod: set", () => {
  const schema = z.set(z.string());
  expectMatch(schema, new Set());
  expectMatch(schema, new Set(["a", "b"]));
  expectMatch(schema, new Set([1, 2]));
  expectMatch(schema, []);
});

// === Template Literal ===

test("template literal basic", () => {
  const aot = compile(z.templateLiteral([z.literal("hello"), z.literal("-"), z.literal("world")]));
  expect(valid(aot, "hello-world")).toBe("hello-world");
  invalid(aot, "hello-world!");
  invalid(aot, "helloworld");
  invalid(aot, 123);
});

test("template literal with types", () => {
  const aot = compile(z.templateLiteral(["user-", z.number()]));
  expect(valid(aot, "user-123")).toBe("user-123");
  expect(valid(aot, "user-0")).toBe("user-0");
  invalid(aot, "user-abc");
  invalid(aot, "admin-123");
});

test("matches Zod: template literal", () => {
  const schema = z.templateLiteral(["id-", z.number()]);
  expectMatch(schema, "id-123");
  expectMatch(schema, "id-abc");
  expectMatch(schema, "other-123");
});

// === Lazy ===

test("lazy basic", () => {
  const aot = compile(z.lazy(() => z.string()));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, 123);
});

test("lazy recursive schemas are refused, and still parse through the runtime", () => {
  interface Node {
    value: string;
    next?: Node | undefined;
  }
  const nodeSchema: z.ZodType<Node> = z.object({
    value: z.string(),
    next: z.lazy(() => nodeSchema).optional(),
  });

  // A recursive schema is re-entered by a single parse, which is how the runtime memoizer terminates input containing a reference cycle. That state is keyed on the parse context, and the fast path has none, so it declines the schema rather than following the cycle until the stack runs out.
  expect(() => compile(nodeSchema, { strict: true })).toThrow(ZodCompileUnsupportedError);

  expect(valid(nodeSchema, { value: "a" })).toEqual({ value: "a" });
  expect(valid(nodeSchema, { value: "a", next: { value: "b" } })).toEqual({ value: "a", next: { value: "b" } });
  invalid(nodeSchema, { value: "a", next: { value: 123 } });
  invalid(nodeSchema, { value: 123 });

  // The case the refusal exists for: cyclic input parses instead of crashing.
  const cyclic: any = { value: "a" };
  cyclic.next = cyclic;
  expect(() => nodeSchema.parse(cyclic)).not.toThrow();
});

test("matches Zod: lazy", () => {
  const schema = z.lazy(() => z.string());
  expectMatch(schema, "hello");
  expectMatch(schema, 123);
});

// === Pipe ===

test("pipe without transform", () => {
  // Pipe with both schemas validating the same type
  const aot = compile(z.string().pipe(z.string().min(3)));
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "ab");
  invalid(aot, 123);
});

test("matches Zod: pipe without transform", () => {
  const schema = z.string().pipe(z.string().min(3));
  expectMatch(schema, "hello");
  expectMatch(schema, "ab");
  expectMatch(schema, 123);
});

// === Custom / Instanceof ===

test("instanceof", () => {
  class MyClass {
    value: number;
    constructor(v: number) {
      this.value = v;
    }
  }

  const aot = compile(z.instanceof(MyClass));
  const instance = new MyClass(1);
  expect(valid(aot, instance)).toBe(instance);
  invalid(aot, { value: 1 });
  invalid(aot, null);
});

test("instanceof Date", () => {
  const aot = compile(z.instanceof(Date));
  const d = new Date();
  expect(valid(aot, d)).toBe(d);
  invalid(aot, "2024-01-01");
  invalid(aot, {});
});

test("matches Zod: instanceof", () => {
  class Test {}
  const schema = z.instanceof(Test);
  expectMatch(schema, new Test());
  expectMatch(schema, {});
  expectMatch(schema, null);
});

// === Bigint Format Checks ===

test("bigint int64 format", () => {
  const aot = compile(z.int64());
  expect(valid(aot, 0n)).toBe(0n);
  expect(valid(aot, 9223372036854775807n)).toBe(9223372036854775807n);
  expect(valid(aot, -9223372036854775808n)).toBe(-9223372036854775808n);
  invalid(aot, 9223372036854775808n); // too big
  invalid(aot, -9223372036854775809n); // too small
});

test("bigint uint64 format", () => {
  const aot = compile(z.uint64());
  expect(valid(aot, 0n)).toBe(0n);
  expect(valid(aot, 18446744073709551615n)).toBe(18446744073709551615n);
  invalid(aot, -1n); // negative
  invalid(aot, 18446744073709551616n); // too big
});

test("matches Zod: bigint format", () => {
  const schema = z.int64();
  expectMatch(schema, 0n);
  expectMatch(schema, 9223372036854775807n);
  expectMatch(schema, 9223372036854775808n);
});

// === Nullish (combines optional + nullable) ===

test("nullish", () => {
  const aot = compile(z.string().nullish());
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, null)).toBe(null);
  expect(valid(aot, undefined)).toBe(undefined);
  invalid(aot, 123);
});

test("matches Zod: nullish", () => {
  const schema = z.string().nullish();
  expectMatch(schema, "hello");
  expectMatch(schema, null);
  expectMatch(schema, undefined);
  expectMatch(schema, 123);
});

// === Codec (extends pipe with transform) ===
// Note: Codecs involve transforms, so AOT validates input and executes transforms.

test("codec validates and transforms", () => {
  // stringbool is a codec from string to boolean
  const aot = compile(z.stringbool());
  expect(valid(aot, "true")).toBe(true);
  expect(valid(aot, "false")).toBe(false);
  expect(valid(aot, "1")).toBe(true);
  expect(valid(aot, "0")).toBe(false);
  invalid(aot, 123); // Not a string
  invalid(aot, null);
});

// === SuperRefine ===

test("superRefine basic", () => {
  const schema = z.string().superRefine((val, ctx) => {
    if (val.length < 3) {
      ctx.addIssue({ code: "custom", message: "Too short" });
    }
  });
  const aot = compile(schema);
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "ab");
  invalid(aot, 123);
});

test("superRefine with multiple issues", () => {
  const schema = z.number().superRefine((val, ctx) => {
    if (val < 0) ctx.addIssue({ code: "custom", message: "Must be positive" });
    if (val > 100) ctx.addIssue({ code: "custom", message: "Must be <= 100" });
  });
  const aot = compile(schema);
  expect(valid(aot, 50)).toBe(50);
  invalid(aot, -1);
  invalid(aot, 101);
});

test("matches Zod: superRefine", () => {
  const schema = z.string().superRefine((val, ctx) => {
    if (!val.includes("@")) {
      ctx.addIssue({ code: "custom", message: "Must contain @" });
    }
  });
  expectMatch(schema, "test@example.com");
  expectMatch(schema, "invalid");
  expectMatch(schema, 123);
});

// === Transform ===

test("transform basic", () => {
  const schema = z.string().transform((val) => val.toUpperCase());
  const aot = compile(schema);
  expect(valid(aot, "hello")).toBe("HELLO"); // Transform succeeds
  invalid(aot, 123); // Not a string (fails before transform)
});

test("transform with validation", () => {
  const schema = z.string().transform((val, ctx) => {
    if (val.length === 0) {
      ctx.addIssue({ code: "custom", message: "Empty string" });
      return z.NEVER;
    }
    return val.length;
  });
  const aot = compile(schema);
  expect(valid(aot, "hello")).toBe(5);
  invalid(aot, ""); // Transform adds issue
});

test("matches Zod: transform", () => {
  const schema = z.string().transform((val) => val.length);
  expectMatch(schema, "hello");
  expectMatch(schema, 123);
});

// === Overwrite Checks (trim, toLowerCase, toUpperCase) ===

test("trim", () => {
  const schema = z.string().trim();
  const aot = compile(schema);

  // AOT validates the input type and applies trim transform
  expect(valid(aot, "  hello  ")).toBe("hello");
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, "")).toBe("");
  invalid(aot, 123);
});

test("toLowerCase", () => {
  const schema = z.string().toLowerCase();
  const aot = compile(schema);

  // AOT validates the input type and applies toLowerCase transform
  expect(valid(aot, "HELLO")).toBe("hello");
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, "")).toBe("");
  invalid(aot, 123);
});

test("toUpperCase", () => {
  const schema = z.string().toUpperCase();
  const aot = compile(schema);

  // AOT validates the input type and applies toUpperCase transform
  expect(valid(aot, "hello")).toBe("HELLO");
  expect(valid(aot, "HELLO")).toBe("HELLO");
  expect(valid(aot, "")).toBe("");
  invalid(aot, 123);
});

test("chained overwrites", () => {
  const schema = z.string().trim().toLowerCase();
  const aot = compile(schema);

  // AOT validates the input type and applies transforms in order
  expect(valid(aot, "  HELLO  ")).toBe("hello");
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, "")).toBe("");
  invalid(aot, 123);
});

test("overwrite with validation", () => {
  const schema = z.string().trim().min(3);
  const aot = compile(schema);

  // After trim, check min length
  expect(valid(aot, "  hello  ")).toBe("hello"); // "hello" length 5 >= 3
  expect(valid(aot, "hello")).toBe("hello");
  invalid(aot, "  ab  "); // "ab" length 2 < 3
  expect(valid(aot, "abc")).toBe("abc");
  invalid(aot, 123);
});

test("matches Zod: trim", () => {
  const schema = z.string().trim();
  expectMatch(schema, "  hello  ");
  expectMatch(schema, "hello");
  expectMatch(schema, 123);
});

test("matches Zod: toLowerCase", () => {
  const schema = z.string().toLowerCase();
  expectMatch(schema, "HELLO");
  expectMatch(schema, "hello");
  expectMatch(schema, 123);
});

test("matches Zod: toUpperCase", () => {
  const schema = z.string().toUpperCase();
  expectMatch(schema, "hello");
  expectMatch(schema, "HELLO");
  expectMatch(schema, 123);
});

test("matches Zod: chained overwrites", () => {
  const schema = z.string().trim().toLowerCase();
  expectMatch(schema, "  HELLO  ");
  expectMatch(schema, "hello");
  expectMatch(schema, 123);
});

test("matches Zod: overwrite with validation", () => {
  const schema = z.string().trim().min(3);
  expectMatch(schema, "  hello  ");
  expectMatch(schema, "  ab  ");
  expectMatch(schema, "abc");
  expectMatch(schema, 123);
});

// === Regressions tracking main ===

test("object catchall ignores __proto__ key (#5898)", () => {
  // Passthrough variant
  const loose = compile(z.looseObject({ name: z.string() }));
  const polluted = JSON.parse('{"name":"ok","__proto__":{"polluted":true}}');
  const out = valid(loose, polluted) as Record<string, unknown>;
  expect(Object.getPrototypeOf(out)).toBe(Object.prototype);
  expect((out as { polluted?: unknown }).polluted).toBeUndefined();

  // Schema-typed catchall
  const typed = compile(z.object({ name: z.string() }).catchall(z.number()));
  const out2 = valid(typed, JSON.parse('{"name":"ok","extra":1}')) as Record<string, unknown>;
  expect(Object.getPrototypeOf(out2)).toBe(Object.prototype);
});

test("multipleOf with sub-integer step uses float tolerance (#5793)", () => {
  const aot = compile(z.number().multipleOf(1e-7));
  expect(valid(aot, 0)).toBe(0);
  expect(valid(aot, 1e-7)).toBe(1e-7);
  expect(valid(aot, 3e-7)).toBe(3e-7);
  invalid(aot, 2.5e-7);
  invalid(aot, 1.5e-7);
});

test("tuple with trailing optionals accepts short input (#5661)", () => {
  const schema = z.tuple([z.string(), z.number().optional()]);
  const aot = compile(schema);
  expect(valid(aot, ["a"])).toEqual(["a"]);
  expect(valid(aot, ["a", 1])).toEqual(["a", 1]);
  invalid(aot, []);
  invalid(aot, ["a", "b"]);
  invalid(aot, ["a", 1, "extra"]);
});

test("tuple exactOptional rejects explicit undefined but accepts absence", () => {
  const aot = compile(z.tuple([z.string().exactOptional()]));
  expect(valid(aot, [])).toEqual([]);
  expect(valid(aot, ["x"])).toEqual(["x"]);
  invalid(aot, [undefined]);
  invalid(aot, [1]);
});

test("tuple mixed required and exactOptional", () => {
  const aot = compile(z.tuple([z.number(), z.string().exactOptional(), z.boolean().exactOptional()]));
  expect(valid(aot, [1])).toEqual([1]);
  expect(valid(aot, [1, "x"])).toEqual([1, "x"]);
  expect(valid(aot, [1, "x", true])).toEqual([1, "x", true]);
  invalid(aot, []);
  invalid(aot, [1, undefined]);
  invalid(aot, [1, "x", undefined]);
  invalid(aot, [1, "x", true, "extra"]);
});

test("tuple optional vs exactOptional differ on explicit undefined", () => {
  const opt = compile(z.tuple([z.string().optional()]));
  expect(valid(opt, [])).toEqual([]);
  expect(valid(opt, [undefined])).toEqual([undefined]);

  const exact = compile(z.tuple([z.string().exactOptional()]));
  expect(valid(exact, [])).toEqual([]);
  invalid(exact, [undefined]);
});

test("default() shallow-clones Map/Set/array/object (#5855)", () => {
  const mapSchema = z.map(z.string(), z.number()).default(new Map([["a", 1]]));
  const mapFn = compile(mapSchema);
  const m1 = valid(mapFn, undefined) as Map<string, number>;
  const m2 = valid(mapFn, undefined) as Map<string, number>;
  expect(m1).not.toBe(m2);
  m1.set("b", 2);
  expect(m2.has("b")).toBe(false);

  const setSchema = z.set(z.string()).default(new Set(["x"]));
  const setFn = compile(setSchema);
  const s1 = valid(setFn, undefined) as Set<string>;
  const s2 = valid(setFn, undefined) as Set<string>;
  expect(s1).not.toBe(s2);
});

test("multi-value literal accepts each value", () => {
  const aot = compile(z.literal(["a", "b", 1]));
  expect(valid(aot, "a")).toBe("a");
  expect(valid(aot, "b")).toBe("b");
  expect(valid(aot, 1)).toBe(1);
  invalid(aot, "c");
  invalid(aot, 2);
});

// === Phase 1: schema-clone + fallback contract ===

test("compile returns a fresh clone; original schema is untouched", () => {
  const original = z.object({ name: z.string() });
  const originalRun = original._zod.run;
  const compiled = compile(original);
  expect(compiled).not.toBe(original);
  expect(original._zod.run).toBe(originalRun);
  expect(compiled._zod.run).not.toBe(originalRun);
  // shape def is shared by reference; cloning is structural at the top
  expect(compiled._zod.def).toBe(original._zod.def);
});

test("fallback produces ZodError identical to the original schema", () => {
  const schema = z.object({ name: z.string(), age: z.number().min(0) });
  const compiled = compile(schema);
  const cases: unknown[] = [
    { name: 123, age: 30 },
    { name: "ok", age: -5 },
    { name: "ok", age: "thirty" },
    null,
    [],
    { name: "ok" },
  ];
  for (const value of cases) {
    const a = schema.safeParse(value);
    const b = compiled.safeParse(value);
    expect(b.success).toBe(a.success);
    if (!a.success && !b.success) {
      expect(b.error.issues).toEqual(a.error.issues);
    }
  }
});

test("fallback preserves instanceof class name in error message", () => {
  class User {}
  const schema = z.instanceof(User);
  const compiled = compile(schema);
  expect(compiled.safeParse(new User()).success).toBe(true);
  const bad = compiled.safeParse({});
  expect(bad.success).toBe(false);
  if (!bad.success) {
    // The error must come from the original schema's runtime, which captured `inst` referring to the original. Class name surfaces in the message.
    expect(bad.error.issues[0]?.message).toMatch(/User/);
  }
});

test("compile bypasses fast path for backward direction (codec encode)", () => {
  const codec = z.stringbool();
  const compiled = compile(codec);
  expect(compiled.safeParse("true").data).toBe(true);
  expect(compiled.safeParse("false").data).toBe(false);
  expect(compiled.encode(true)).toBe("true");
  expect(compiled.encode(false)).toBe("false");
});

test("compile bypasses fast path for safeParseAsync", async () => {
  const schema = z.string().min(3);
  const compiled = compile(schema);
  const r = await compiled.safeParseAsync("ok");
  expect(r.success).toBe(false);
  const ok = await compiled.safeParseAsync("hello");
  expect(ok.success).toBe(true);
});

test("ZodCompileAsyncError thrown on async refinement", () => {
  const schema = z.string().refine(async () => true);
  expect(() => compile(schema, { strict: true })).toThrow(ZodCompileAsyncError);
});

test("ZodCompileAsyncError thrown on async transform", () => {
  const schema = z.string().transform(async (s) => s.length);
  expect(() => compile(schema, { strict: true })).toThrow(ZodCompileAsyncError);
});

test("compiled clone is composable inside another schema", () => {
  const inner = z.object({ name: z.string() });
  const compiledInner = compile(inner);
  const outer = z.object({ user: compiledInner, count: z.number() });
  const r = outer.safeParse({ user: { name: "ok" }, count: 1 });
  expect(r.success).toBe(true);
  if (r.success) expect(r.data).toEqual({ user: { name: "ok" }, count: 1 });
  const bad = outer.safeParse({ user: { name: 1 }, count: 1 });
  expect(bad.success).toBe(false);
});

// === catch ===

test("catch over primitive", () => {
  const aot = compile(z.catch(z.string(), "fallback"));
  expect(valid(aot, "hello")).toBe("hello");
  expect(valid(aot, 123)).toBe("fallback");
  expect(valid(aot, undefined)).toBe("fallback");
});

test("catch as object property", () => {
  const aot = compile(z.object({ name: z.catch(z.string(), "anon") }));
  expect(valid(aot, { name: "Alice" })).toEqual({ name: "Alice" });
  expect(valid(aot, { name: 123 })).toEqual({ name: "anon" });
  expect(valid(aot, {})).toEqual({ name: "anon" });
});

test("a catch callback reading ctx is refused; a constant catch compiles", () => {
  // Finalizing the issues the callback sees depends on the caller's per-parse error map, which generated code never receives — the compiled path produced the default message where `.parse(input, { error })` produces the mapped one. Refuse it, so a union treats it as uncompilable rather than as a rejected branch.
  const reads = z.catch(z.string().min(5), (ctx) => `bad:${ctx.error.issues.length}`);
  expect(() => compile(reads, { strict: true })).toThrow(ZodCompileUnsupportedError);
  expect(reads.parse("hi")).toBe("bad:1");
  expect(reads.parse(42 as never)).toMatch(/^bad:\d+$/);

  // A constant catch value needs no issues at all, so it keeps the fast path.
  const constant = compile(z.catch(z.string().min(5), "fb"));
  expect(valid(constant, "hello world")).toBe("hello world");
  expect(valid(constant, "hi")).toBe("fb");
  expect(valid(constant, 42)).toBe("fb");
});

test("catch falls through unsupported inner via runtime island", () => {
  // Async refine in the inner makes the inner uncompilable, but catch should still compile by treating the whole catch as a runtime island.
  const aot = compile(z.catch(z.union([z.string(), z.number()]), "fb"));
  expect(valid(aot, "x")).toBe("x");
  expect(valid(aot, 1)).toBe(1);
  expect(valid(aot, true)).toBe("fb");
});

// === IPv6 / CIDRv6 hoisted helpers ===

test("ipv6 compiled rejects regex-passing but URL-rejecting values", () => {
  const aot = compile(z.ipv6());
  expect(valid(aot, "::1")).toBe("::1");
  expect(valid(aot, "2001:db8::1")).toBe("2001:db8::1");
  // "0:0:0:0:0:0:0:1:1" matches the IPv6 regex but `new URL` rejects it.
  invalid(aot, "0:0:0:0:0:0:0:1:1");
  // Differential: confirm runtime and compiled agree on this fixture.
  expectMatch(z.ipv6(), "0:0:0:0:0:0:0:1:1");
});

test("cidrv6 compiled validates prefix range and address", () => {
  const aot = compile(z.cidrv6());
  expect(valid(aot, "::1/128")).toBe("::1/128");
  invalid(aot, "::1/129");
  invalid(aot, "::1/-1");
  invalid(aot, "not-an-address/64");
  invalid(aot, "::1");
  expectMatch(z.cidrv6(), "::1/129");
});

// === Runtime islands ===

test("runtime island falls through unsupported child inside object", () => {
  // z.xor (exclusive union) currently throws ZodCompileUnsupportedError. As an object property, the island should let the rest of the object compile.
  const aot = compile(
    z.object({
      label: z.string(),
      payload: z.xor([z.string(), z.number()]),
    })
  );
  expect(valid(aot, { label: "ok", payload: "x" })).toEqual({ label: "ok", payload: "x" });
  invalid(aot, { label: "ok", payload: true });
  invalid(aot, { label: 1, payload: "x" });
});

test("runtime island inside array element", () => {
  const aot = compile(z.array(z.xor([z.string(), z.number()])));
  expect(valid(aot, ["a", 1, "b"])).toEqual(["a", 1, "b"]);
  invalid(aot, ["a", true]);
});

test("url string-format check never assigns to its accessor", () => {
  // const accessor (array element): previously emitted `elem = normalized`,
  // a TypeError on valid input.
  const arr = compile(z.array(z.string().url()));
  expect(valid(arr, ["https://example.com"])).toEqual(["https://example.com"]);
  invalid(arr, ["not a url"]);

  // property accessor: previously wrote the normalized value back into the caller's input object.
  const padded = " https://example.com ";
  const input = { u: padded };
  expectMatch(z.object({ u: z.string().url() }), input);
  expect(input.u).toBe(padded);
});

test("lazy schemas with checked or defaulted descendants parse without crashing", () => {
  // Inner runtime run must receive a ctx — checks read ctx.skipChecks, default/transform read ctx.direction.
  const aot = compile(z.lazy(() => z.string().min(2)));
  expect(valid(aot, "abc")).toEqual("abc");
  invalid(aot, "a");

  // Recursive, so the fast path declines it; the runtime still parses it.
  const tree: z.ZodType = z.lazy(() => z.object({ v: z.number().int(), kids: z.array(tree).default([]) }));
  expect(() => compile(tree, { strict: true })).toThrow(ZodCompileUnsupportedError);
  expect(valid(tree, { v: 1, kids: [{ v: 2 }] })).toEqual({ v: 1, kids: [{ v: 2, kids: [] }] });
  invalid(tree, { v: 1.5 });
});

test("sync refine returning a Promise rejects like the runtime", () => {
  const schema = z.string().refine((() => Promise.resolve(true)) as unknown as (v: string) => boolean);
  const aot = compile(schema);
  let runtimeErr: string | undefined;
  let compiledErr: string | undefined;
  try {
    schema.parse("x");
  } catch (e) {
    runtimeErr = (e as Error).name;
  }
  try {
    aot.parse("x");
  } catch (e) {
    compiledErr = (e as Error).name;
  }
  expect(runtimeErr).toBeDefined();
  expect(compiledErr).toBe(runtimeErr);
});

test("literal-union Set optimization respects checks and multi-value literals", () => {
  const withCheck = z.union([z.literal("a").refine(() => false), z.literal("b")]);
  expectMatch(withCheck, "a"); // runtime rejects via refine; compiled must too
  expectMatch(withCheck, "b");

  const multi = z.union([z.literal(["a", "b"]), z.literal("c")]);
  for (const v of ["a", "b", "c", "d"]) expectMatch(multi, v);
});

test("xor and custom when-gated checks force runtime fallback", () => {
  expect(() => compile(z.xor([z.string(), z.number()]), { strict: true })).toThrow(ZodCompileUnsupportedError);
  // Multi-match must reject — verified through the object island.
  expectMatch(z.object({ v: z.xor([z.number(), z.number().int()]) }), { v: 2 });
  expectMatch(z.object({ v: z.xor([z.number(), z.number().int()]) }), { v: 1.5 });

  const gated = z.number().gt(5);
  (gated._zod.def.checks![0]!._zod.def as { when?: unknown }).when = () => false;
  expect(() => compile(gated, { strict: true })).toThrow(ZodCompileUnsupportedError);
  expectMatch(z.object({ n: gated }), { n: 3 }); // runtime skips the gated check
});

test("strict objects reject inherited enumerable keys like the runtime", () => {
  const schema = z.strictObject({ a: z.string() });
  expectMatch(schema, Object.assign(Object.create({ extra: 1 }), { a: "x" }));
  expectMatch(schema, { a: "x" });
  // Own __proto__ keys are skipped by the runtime, not unrecognized.
  expectMatch(schema, JSON.parse('{"a":"x","__proto__":{"polluted":true}}'));

  const withOptional = z.strictObject({ a: z.string(), b: z.string().optional() });
  expectMatch(withOptional, Object.assign(Object.create({ extra: 1 }), { a: "x" }));
  expectMatch(withOptional, JSON.parse('{"a":"x","__proto__":{}}'));
});

test("object output parity: key order, undefined keys, inherited keys, getters", () => {
  // Loose object: shape keys precede unknown keys in the output.
  const loose = z.looseObject({ a: z.string() });
  const looseIn = { x: 1, a: "q", y: 2 };
  expect(Object.keys(compile(loose).parse(looseIn) as object)).toEqual(Object.keys(loose.parse(looseIn)));

  const cat = z.object({ a: z.string() }).catchall(z.number());
  const catIn = { x: 1, a: "q" };
  expect(Object.keys(compile(cat).parse(catIn) as object)).toEqual(Object.keys(cat.parse(catIn)));

  // optin-optional/optout-required prop: absent key omitted, explicit undefined preserved (runtime handlePropertyResult rule).
  const tf = z.object({
    a: z
      .string()
      .optional()
      .transform((v) => v),
  });
  expect("a" in (compile(tf).parse({}) as object)).toBe(false);
  expect("a" in tf.parse({})).toBe(false);
  const opt = z.object({ a: z.string().optional() });
  expect(Object.keys(compile(opt).parse({ a: undefined }) as object)).toEqual(["a"]);

  // Empty-shape loose: inherited enumerable keys included, own __proto__ dropped.
  const empty = z.looseObject({});
  const inherited = Object.assign(Object.create({ extra: 1 }), { own: 2 });
  expect(compile(empty).parse(inherited)).toEqual({ own: 2, extra: 1 });
  expect(empty.parse(inherited)).toEqual({ own: 2, extra: 1 });
  const protoIn = JSON.parse('{"__proto__":{"polluted":1},"x":2}');
  expect(Object.keys(compile(empty).parse(protoIn) as object)).toEqual(Object.keys(empty.parse(protoIn)));

  // Getters are read exactly once, like the runtime.
  let reads = 0;
  const getterIn = {
    get a() {
      reads++;
      return "v";
    },
  };
  expect(compile(z.object({ a: z.string().min(1) })).parse(getterIn)).toEqual({ a: "v" });
  expect(reads).toBe(1);
});

// === Error taxonomy ===

test("unsupported features throw ZodCompileUnsupportedError, not raw errors", () => {
  // __proto__ shape key: output object literal would set the prototype.
  expect(() => compile(z.object({ ["__proto__"]: z.string() }), { strict: true })).toThrow(ZodCompileUnsupportedError);
  // Exclusive unions need every branch's failure to be a real runtime failure.
  expect(() => compile(z.xor([z.object({ a: z.string() }), z.object({ b: z.string() })]), { strict: true })).toThrow(
    ZodCompileUnsupportedError
  );
  // NaN comparison bounds can't compile to a faithful comparison.
  expect(() => compile(z.number().gt(Number.NaN), { strict: true })).toThrow(ZodCompileUnsupportedError);
  // A zero bigint divisor has no compiled form: `x % 0n` throws.
  expect(() => compile(z.bigint().multipleOf(BigInt(0)), { strict: true })).toThrow(ZodCompileUnsupportedError);
  // Unsupported children still island inside containers.
  const aot = compile(z.object({ a: z.string(), x: z.xor([z.literal("p"), z.literal("q")]) }));
  expect(valid(aot, { a: "x", x: "p" })).toEqual({ a: "x", x: "p" });
  invalid(aot, { a: "x", x: "z" });
});

test("record key schemas compile: formats, checks, numbers, transforms", () => {
  // A string format lives on the def rather than in `checks`, so an email key schema reads as a bare `z.string()` unless the key path looks for it.
  for (const [schema, inputs] of [
    [z.record(z.email(), z.number()), [{ "a@b.com": 1 }, { nope: 1 }, {}]],
    [z.record(z.string().min(2), z.number()), [{ ab: 1 }, { a: 1 }]],
    [z.record(z.string().regex(/^k_/), z.number()), [{ k_a: 1 }, { x: 1 }]],
    // Numeric keys arrive stringified; the runtime retries them as numbers.
    [z.record(z.number(), z.string()), [{ 1: "a" }, { "1.5": "a" }, { x: "a" }]],
    [z.record(z.templateLiteral(["id_", z.string()]), z.number()), [{ id_a: 1 }, { b: 1 }]],
    // The key schema picks the output key, not the input key.
    [
      z.record(
        z
          .string()
          .min(1)
          .overwrite((s: string) => s.toUpperCase()),
        z.number()
      ),
      [{ ab: 1 }, { "": 1 }],
    ],
  ] as [z.ZodType, unknown[]][]) {
    for (const input of inputs) expectMatch(schema, input);
  }

  // Own __proto__ is skipped rather than validated, matching the runtime.
  expectMatch(z.record(z.email(), z.number()), JSON.parse('{"__proto__":{"p":1},"a@b.com":1}'));

  // Coercion is modelled nowhere, so a coercing key schema is refused outright rather than compiled to the bare type test it would otherwise become.
  expect(() => compile(z.record(z.coerce.string(), z.number()), { strict: true })).toThrow(ZodCompileUnsupportedError);

  // A loose record keeps a rejected key verbatim, copying its value across unvalidated instead of failing.
  for (const input of [{ "a@b.com": 1 }, { nope: 1 }, { "a@b.com": 1, nope: "raw" }, { "a@b.com": "bad" }]) {
    expectMatch(z.looseRecord(z.email(), z.number()), input);
  }
});

test("date min/max bounds compile with runtime parity", () => {
  const schema = z.date().min(new Date("2024-01-01")).max(new Date("2025-01-01"));
  const aot = compile(schema);
  const inputs = [new Date("2024-06-15"), new Date("2024-01-01"), new Date("2023-12-31"), new Date("2025-01-02")];
  for (const input of inputs) expectMatch(schema, input);
  expect(valid(aot, inputs[0])).toEqual(inputs[0]);
  invalid(aot, inputs[2]);
});

test("the compiled fallback builds the same Error-shaped error as the runtime", () => {
  const schema = z.object({ a: z.string(), b: z.number() });
  const aot = compile(schema);

  // both fast closures fall back to the runtime on rejection, so the error is the runtime's
  const err = aot.safeParse({ a: 1, b: "x" }).error!;
  expect(err).toBeInstanceOf(Error);
  expect(err).toBeInstanceOf(z.core.$ZodError);
  expect(err.issues).toEqual(schema.safeParse({ a: 1, b: "x" }).error!.issues);

  function callSite() {
    aot.parse({ a: 1, b: "x" });
  }

  let thrown: unknown;
  try {
    callSite();
  } catch (err) {
    thrown = err;
  }
  expect(thrown).toBeInstanceOf(Error);
  expect((thrown as Error).stack).toContain("callSite");
});

// === Never throws ===

// Snapshot a parse outcome structurally, so a refused compile can be shown not to have disturbed it.
function snap(schema: z.ZodType, value: unknown) {
  const r = schema.safeParse(value);
  return r.success ? { ok: true, data: r.data } : { ok: false, issues: r.error.issues };
}

// Every shape the compiler refuses, with inputs that exercise the pass, fail and fallback branches of each.
function refusedCases(): [string, z.ZodType, unknown[]][] {
  const gated = z.number().gt(5);
  (gated._zod.def.checks![0]!._zod.def as { when?: unknown }).when = () => false;
  const tree: z.ZodType = z.lazy(() => z.object({ v: z.number().int(), kids: z.array(tree).default([]) }));

  return [
    ["cycle", tree, [{ v: 1, kids: [{ v: 2 }] }, { v: 1.5 }, "nope"]],
    ["async refine", z.string().refine(async () => true), ["a", 1]],
    ["async transform", z.string().transform(async (s) => s.length), ["a", 1]],
    ["async custom", z.custom(async () => true), ["a"]],
    ["xor", z.xor([z.string(), z.number()]), ["a", 1, true]],
    ["coerce", z.coerce.number(), ["5", 5, Symbol("x")]],
    ["catch callback", z.catch(z.string().min(5), (c) => `bad:${c.error.issues.length}`), ["hello world", "hi", 42]],
    ["when-gated check", gated, [3, 9, "x"]],
    ["__proto__ key", z.object({ ["__proto__"]: z.string() }), [{}, { a: 1 }]],
    ["NaN bound", z.number().gt(Number.NaN), [1, "x"]],
    ["zero bigint divisor", z.bigint().multipleOf(BigInt(0)), [BigInt(4), "x"]],
    ["coercing record key", z.record(z.coerce.string(), z.number()), [{ a: 1 }, { a: "x" }]],
  ];
}

test("compile hands back the original schema instead of throwing", () => {
  for (const [name, schema] of refusedCases()) {
    expect(() => compile(schema, { strict: true }), name).toThrow();
    // No wrapper and no clone: the uncompilable schema is its own fallback, exactly as global mode leaves it.
    expect(compile(schema), name).toBe(schema);
  }
});

test("a refused compile leaves the schema parsing identically", () => {
  for (const [name, schema, inputs] of refusedCases()) {
    // Async schemas throw $ZodAsyncError out of a sync parse; that path is covered separately.
    if (name.startsWith("async")) continue;
    const before = inputs.map((i) => snap(schema, i));
    compile(schema);
    expect(
      inputs.map((i) => snap(schema, i)),
      name
    ).toEqual(before);
  }
});

test("a refused compile keeps cyclic input parsing", () => {
  const nodeSchema: z.ZodType = z.object({ value: z.string(), next: z.lazy(() => nodeSchema).optional() });
  const cyclic: any = { value: "a" };
  cyclic.next = cyclic;
  expect(() => compile(nodeSchema).parse(cyclic)).not.toThrow();
});

test("a refused async compile parses async and rejects sync like the runtime", async () => {
  const schema = z.string().refine(async (s) => s.length > 1);
  const aot = compile(schema);
  expect(aot).toBe(schema);

  await expect(aot.parseAsync("ab")).resolves.toBe("ab");
  const bad = await aot.safeParseAsync("a");
  expect(bad.success).toBe(false);
  expect(bad.error!.issues).toEqual((await schema.safeParseAsync("a")).error!.issues);
  expect(() => aot.parse("ab")).toThrow(z.core.$ZodAsyncError);
});

test("strict is per-call, so a supported schema compiles either way", () => {
  const schema = z.object({ a: z.string(), b: z.number() });
  for (const aot of [compile(schema), compile(schema, { strict: true }), compile(schema, { strict: false })]) {
    expect(aot).not.toBe(schema);
    expect(valid(aot, { a: "x", b: 1 })).toEqual({ a: "x", b: 1 });
    invalid(aot, { a: 1, b: 1 });
  }
});
