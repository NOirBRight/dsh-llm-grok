// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.
import { APIResource } from "../core/resource.mjs";
/**
 * Given text and/or image inputs, classifies if those inputs are potentially harmful.
 */
export class Moderations extends APIResource {
    /**
     * Classifies if text and/or image inputs are potentially harmful. Learn more in
     * the [moderation guide](https://platform.openai.com/docs/guides/moderation).
     */
    create(body, options) {
        return this._client.post('/moderations', { body, ...options, __security: { bearerAuth: true } });
    }
}
//# sourceMappingURL=moderations.mjs.map