import { Command as $Command } from "@smithy/core/client";
import { getEndpointPlugin } from "@smithy/core/endpoints";
import { commonParams } from "../endpoint/EndpointParameters";
import { InvokeModelWithResponseStream$ } from "../schemas/schemas_0";
export { $Command };
export class InvokeModelWithResponseStreamCommand extends $Command
    .classBuilder()
    .ep(commonParams)
    .m(function (Command, cs, config, o) {
    return [getEndpointPlugin(config, Command.getEndpointParameterInstructions())];
})
    .s("AmazonBedrockFrontendService", "InvokeModelWithResponseStream", {
    eventStream: {
        output: true,
    },
})
    .n("BedrockRuntimeClient", "InvokeModelWithResponseStreamCommand")
    .sc(InvokeModelWithResponseStream$)
    .build() {
}
